package com.example.hh;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        Intent intent = getIntent();
        String name = intent.getStringExtra("Name");
        int age = intent.getIntExtra("Age", 0);
        int mobile = intent.getIntExtra("Mobile_Number", 0);
        int DOB = intent.getIntExtra("DOB", 0);
        String address = intent.getStringExtra("Address");

        TextView textview1 = findViewById(R.id.textView);
        TextView textview2 = findViewById(R.id.textView2);
        TextView textview4 = findViewById(R.id.textView3);
        TextView textview3 = findViewById(R.id.textView4);
        TextView textview5 = findViewById(R.id.textView5);

        textview1.setText("Name: " + name);
        textview2.setText("Age: " + String.valueOf(age));
        textview3.setText("Mobile_Number: " + String.valueOf(mobile));
        textview4.setText("DOB: " + String.valueOf(DOB));
        textview5.setText("Address :" + address);
    }
}