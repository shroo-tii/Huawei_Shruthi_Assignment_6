package com.example.hh;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }
    public void Sign_In(View view){
        EditText editText1 = (EditText) findViewById(R.id.editTextTextPersonName);
        String name = editText1.getText().toString();

        EditText editText2 = (EditText) findViewById(R.id.editTextNumber);
        int age = Integer.parseInt(editText2.getText().toString());

        EditText editText4 = (EditText) findViewById(R.id.editTextPhone);
        int mobile = Integer.parseInt(editText4.getText().toString());

        EditText editText3 = (EditText) findViewById(R.id.editTextDate);
        int DOB = Integer.parseInt(editText3.getText().toString());


        EditText editText5 = (EditText) findViewById(R.id.editTextTextPostalAddress);
        String address = editText5.getText().toString();


        Intent intent = new Intent(MainActivity.this,MainActivity2.class);

        intent.putExtra("Name",name);
        intent.putExtra("Age",age);
        intent.putExtra("Mobile_Number",mobile);
        intent.putExtra("DOB",DOB);
        intent.putExtra("Address",address);

        startActivity(intent);

    }

}